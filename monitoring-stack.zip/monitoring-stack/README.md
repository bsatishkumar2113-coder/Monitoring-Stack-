# Monitoring Stack: Prometheus + Grafana with Docker Compose

Monitors system metrics (node-exporter), container metrics (cAdvisor) and
application metrics (a small instrumented Flask app), with a pre-provisioned
Grafana dashboard and basic alert rules.

## Architecture

    node-exporter --\
    cAdvisor -------+--> Prometheus --> Grafana (dashboard)
    demo app -------/        |
                       alert rules

## Run

    cp .env.example .env        # optional: set a Grafana password
    docker compose up -d --build
    ./generate_load.sh          # optional: create traffic for the app panels

| Service    | URL                    | Notes                         |
|------------|------------------------|-------------------------------|
| Grafana    | http://localhost:3000  | admin / admin by default      |
| Prometheus | http://localhost:9090  | Status > Targets, Alerts      |
| Demo app   | http://localhost:8000  | /, /slow, /flaky, /metrics    |

Open Grafana > Dashboards > "Monitoring Overview". It loads automatically
through provisioning, so there is nothing to import by hand.

## Dashboard panels

- System: targets up, CPU, memory, disk, uptime, CPU/memory over time, network traffic
- Containers: CPU per container (cAdvisor)
- Application: request rate by endpoint, p95 latency, 5xx error rate

## Alert rules (prometheus/alerts.yml)

InstanceDown, HighCpuUsage, HighMemoryUsage, HighErrorRate. They show under
Prometheus > Alerts. Routing to email or Slack would need Alertmanager (a good next step).

## Notes

- On Docker Desktop (Mac/Windows), node-exporter reports the Docker VM, not the host.
- cAdvisor may need extra mounts or privileges on some Linux distros.
- Not tested against a live Docker daemon; config files were syntax-checked and the
  app's /metrics output was verified.
- Stop with `docker compose down` (add `-v` to delete stored data).

## Resume bullets

- Built a monitoring stack with Prometheus and Grafana on Docker Compose, collecting
  host, container and application metrics from node-exporter, cAdvisor and a
  custom-instrumented service.
- Created a provisioned Grafana dashboard (CPU, memory, disk, network, request rate,
  p95 latency, error rate) that loads automatically on startup.
- Defined Prometheus alert rules for instance downtime, resource saturation and
  elevated error rates.
