import random
import time

from flask import Flask, Response, jsonify, request
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest

app = Flask(__name__)

REQUESTS = Counter("app_http_requests_total", "Total HTTP requests", ["method", "endpoint", "status"])
LATENCY = Histogram("app_request_latency_seconds", "Request latency in seconds", ["endpoint"])


@app.before_request
def start_timer():
    request._start = time.perf_counter()


@app.after_request
def record_metrics(response):
    if request.path != "/metrics":
        elapsed = time.perf_counter() - request._start
        LATENCY.labels(request.path).observe(elapsed)
        REQUESTS.labels(request.method, request.path, response.status_code).inc()
    return response


@app.get("/")
def index():
    return jsonify(message="Demo app is running")


@app.get("/slow")
def slow():
    time.sleep(random.uniform(0.1, 1.2))
    return jsonify(message="That was slow")


@app.get("/flaky")
def flaky():
    if random.random() < 0.3:
        return jsonify(error="simulated failure"), 500
    return jsonify(message="ok")


@app.get("/metrics")
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
