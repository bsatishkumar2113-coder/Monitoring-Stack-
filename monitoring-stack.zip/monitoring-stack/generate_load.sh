#!/usr/bin/env bash
# Sends mixed traffic to the demo app so the dashboard has data. Ctrl+C to stop.
while true; do
  curl -s -o /dev/null localhost:8000/
  curl -s -o /dev/null localhost:8000/slow
  curl -s -o /dev/null localhost:8000/flaky
  sleep 0.3
done
